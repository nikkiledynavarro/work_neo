function initModel() {
	var sUrl = "/sap/opu/odata/serperp/CANCEL_SHIP_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}