sap.ui.define([
	"serp/so-shiperp-tab/test/unit/controller/View1.controller"
], function () {
	"use strict";
});