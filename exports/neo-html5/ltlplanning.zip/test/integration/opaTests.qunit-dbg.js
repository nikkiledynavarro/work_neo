/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/erpis/shiperp/hr7/ltlplanning/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});